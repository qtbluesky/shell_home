#!/bin/bash

sed -n 'd/-/g'
